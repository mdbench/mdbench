#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats aggregate cor na.omit qnorm qt rnorm rt
#' @importFrom utils read.csv
## usethis namespace: end
NULL