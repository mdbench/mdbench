## Test Environments
* local OS X / Linux install, R 4.x
* Checked with devtools::check() resulting in 0 errors, 0 warnings, and 1 note (unable to verify current time due to local environment network constraints).

## R CMD check results
There were no ERRORs or WARNINGs. 

## Downstream dependencies
There are currently no downstream dependencies for this package.